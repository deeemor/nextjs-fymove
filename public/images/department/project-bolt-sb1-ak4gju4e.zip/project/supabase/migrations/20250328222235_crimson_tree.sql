/*
  # Create doctor profiles table

  1. New Tables
    - `doctor_profiles`
      - `id` (uuid, primary key, references auth.users)
      - `name` (text)
      - `email` (text)
      - `phone` (text)
      - `specialization` (text)
      - `experience` (text)
      - `address` (text)
      - `hospital` (text)
      - `education` (text)
      - `avatar_url` (text)
      - `updated_at` (timestamptz)

  2. Security
    - Enable RLS on `doctor_profiles` table
    - Add policies for doctors to read/update their own profile
*/

CREATE TABLE IF NOT EXISTS doctor_profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id),
  name text NOT NULL,
  email text NOT NULL,
  phone text,
  specialization text,
  experience text,
  address text,
  hospital text,
  education text,
  avatar_url text,
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE doctor_profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Doctors can view own profile"
  ON doctor_profiles
  FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Doctors can update own profile"
  ON doctor_profiles
  FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);
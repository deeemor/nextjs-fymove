const User = require('../models/User');
const asyncHandler = require('express-async-handler');

// @desc    Get user profile
// @route   GET /api/auth/profile
// @access  Private
const getProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user.id).select('-password');
  
  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }

  res.status(200).json(user);
});

// @desc    Update user profile
// @route   PUT /api/auth/profile
// @access  Private
const updateProfile = asyncHandler(async (req, res) => {
  const user = await User.findById(req.user.id);

  if (!user) {
    res.status(404);
    throw new Error('User not found');
  }

  // Update fields
  const {
    name,
    email,
    phone,
    specialization,
    experience,
    address,
    hospital,
    education
  } = req.body;

  // Check if email is already taken by another user
  if (email && email !== user.email) {
    const emailExists = await User.findOne({ email });
    if (emailExists) {
      res.status(400);
      throw new Error('Email already exists');
    }
  }

  user.name = name || user.name;
  user.email = email || user.email;
  user.phone = phone || user.phone;
  user.specialization = specialization || user.specialization;
  user.experience = experience || user.experience;
  user.address = address || user.address;
  user.hospital = hospital || user.hospital;
  user.education = education || user.education;

  const updatedUser = await user.save();

  res.status(200).json({
    _id: updatedUser._id,
    name: updatedUser.name,
    email: updatedUser.email,
    phone: updatedUser.phone,
    specialization: updatedUser.specialization,
    experience: updatedUser.experience,
    address: updatedUser.address,
    hospital: updatedUser.hospital,
    education: updatedUser.education,
    role: updatedUser.role
  });
});

module.exports = {
  getProfile,
  updateProfile
};